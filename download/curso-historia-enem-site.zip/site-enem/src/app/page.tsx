import Link from 'next/link';
import { modulos, getTotalAulas } from '@/data/curso';

export default function Home() {
  const totalAulas = getTotalAulas();
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-800">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMiIvPjwvZz48L2c+PC9zdmc+')] opacity-40"></div>
        
        <div className="container mx-auto px-4 py-20 relative">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full text-white/80 text-sm mb-6">
              <span className="animate-pulse">🔥</span>
              <span>Conteúdo atualizado para ENEM 2025</span>
            </div>
            
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Domine <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500">História</span> para o ENEM
            </h1>
            
            <p className="text-xl text-white/80 mb-8 max-w-2xl mx-auto">
              Um curso completo e gratuito com todos os temas que você precisa para gabaritar História no ENEM. Estude no seu ritmo, de qualquer lugar.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/modulos" className="px-8 py-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-gray-900 font-bold rounded-xl hover:scale-105 transition-transform shadow-lg shadow-orange-500/30">
                Começar a Estudar 🚀
              </Link>
              <Link href="#modulos" className="px-8 py-4 bg-white/10 backdrop-blur-sm text-white font-semibold rounded-xl hover:bg-white/20 transition-colors border border-white/20">
                Ver Módulos
              </Link>
            </div>
          </div>
          
          {/* Stats */}
          <div className="max-w-3xl mx-auto mt-16 grid grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-white">{modulos.length}</div>
              <div className="text-white/60 text-sm">Módulos</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white">{totalAulas}+</div>
              <div className="text-white/60 text-sm">Aulas</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-white">100%</div>
              <div className="text-white/60 text-sm">Gratuito</div>
            </div>
          </div>
        </div>
      </section>

      {/* Módulos Section */}
      <section id="modulos" className="py-20 bg-black/20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Escolha um Módulo
            </h2>
            <p className="text-white/60 max-w-xl mx-auto">
              Cada módulo cobre uma área importante da História cobrada no ENEM. Clique para ver todas as aulas disponíveis.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {modulos.map((modulo) => (
              <Link
                key={modulo.id}
                href={`/modulos/${modulo.slug}`}
                className="group relative bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6 hover:bg-white/10 transition-all hover:scale-105 hover:shadow-xl"
              >
                <div 
                  className="w-16 h-16 rounded-xl flex items-center justify-center text-3xl mb-4"
                  style={{ backgroundColor: `${modulo.cor}20` }}
                >
                  {modulo.icone}
                </div>
                
                <h3 className="text-xl font-bold text-white mb-2 group-hover:text-yellow-400 transition-colors">
                  {modulo.titulo}
                </h3>
                
                <p className="text-white/60 text-sm mb-4 line-clamp-2">
                  {modulo.descricao}
                </p>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm text-white/40">
                    {modulo.aulas.length} aulas
                  </span>
                  <span className="text-white/40 group-hover:text-yellow-400 group-hover:translate-x-1 transition-all">
                    →
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12">
              Por que estudar conosco?
            </h2>
            
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">
                  📚
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Conteúdo Completo</h3>
                <p className="text-white/60">
                  Todos os temas cobrados no ENEM, organizados de forma didática.
                </p>
              </div>
              
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">
                  💡
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">Dicas do ENEM</h3>
                <p className="text-white/60">
                  Questões comentadas e estratégias para gabaritar a prova.
                </p>
              </div>
              
              <div className="text-center p-6">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center text-3xl mx-auto mb-4">
                  🎯
                </div>
                <h3 className="text-xl font-semibold text-white mb-2">100% Gratuito</h3>
                <p className="text-white/60">
                  Sem propagandas, sem cadastro. Apenas conhecimento.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 border-t border-white/10">
        <div className="container mx-auto px-4 text-center">
          <p className="text-white/40 text-sm">
            Curso de História para ENEM • Feito com 💜 para estudantes brasileiros
          </p>
          <p className="text-white/30 text-xs mt-2">
            Hospedado no GitHub Pages • Contribuições bem-vindas
          </p>
        </div>
      </footer>
    </div>
  );
}
